# Erom Música — pacote de melhorias

Contém a interface HTML enviada, com um modo alternativo multicolorido e a estrutura inicial para empacotamento Android.

- `website/index.html`: interface web atualizada.
- `android/`: projeto Android WebView que abre a interface local.

O tema original continua sendo o padrão. Use o botão de cores na interface para alternar os temas. Este pacote ainda precisa de compilação/testes num ambiente com Android SDK e validação das integrações externas.
