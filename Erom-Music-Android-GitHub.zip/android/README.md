# Erom Música Android

Projeto Android inicial que carrega a interface enviada em um WebView local.

## Build
Requer Java 17, Android SDK API 35 e Gradle 8.9 ou compatível. Na pasta `android`, execute `gradle assembleDebug` (ou abra a pasta no Android Studio e compile).

APK esperado: `app/build/outputs/apk/debug/app-debug.apk`.

## Limitações conhecidas
O ZIP original tinha apenas o HTML e um arquivo de instruções. A aplicação carrega esse HTML local, mas integrações que dependam de APIs externas, credenciais OAuth, manifestos/ícones ou arquivos adicionais precisam ser verificadas com as configurações originais. Não coloque chaves secretas no código do cliente.
