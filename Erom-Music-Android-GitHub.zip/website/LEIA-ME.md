# Erom Música — interface melhorada

O tema original monocromático permanece como padrão. O botão **Ativar cores alternativas** alterna para o tema multicolorido e a preferência é guardada localmente no dispositivo.

Este pacote parte do HTML enviado. Como o ZIP original continha apenas o HTML e um LEIA-ME, não inclui os demais recursos externos ou credenciais privados que eventualmente sejam necessários para todos os serviços funcionarem.
