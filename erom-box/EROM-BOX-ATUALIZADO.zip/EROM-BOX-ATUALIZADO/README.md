# EROM BOX

Organizador pessoal de **filmes, séries e desenhos** — temporadas, episódios, progresso automático, estatísticas, cores de destaque e barra de progresso.
Site/PWA + app Android, com login real e sincronização privada entre aparelhos.

| Parte | Tecnologia | Pasta |
|---|---|---|
| Site / PWA | HTML + CSS + JS puro (sem framework), service worker | `public/` |
| Login, banco, RLS, exclusão de conta | Supabase (Auth + Postgres + Edge Function) | `supabase/` |
| Hospedagem | Netlify (`netlify.toml`) | raiz |
| Monitoramento de erros | Sentry (plano gratuito) | `public/assets/monitoring.js` |
| App Android (APK) | Projeto nativo (WebView) compilado pelo GitHub Actions | `android/` |
| App Android (alternativa) | Expo / EAS (WebView do site) | `mobile/` |
| Testes ponta a ponta | Playwright + Supabase simulado | `tests/` |

## Estrutura
```
public/            site (index.html, config.js, sw.js, manifest, assets/, icons/)
supabase/          migrations/ (SQL + RLS) e functions/delete-account
android/           projeto Android nativo (Gradle) — gera o APK via GitHub Actions
apk-github/        ZIP do projeto Android + fluxo build-erombox-apk.yml (para subir no GitHub)
mobile/            projeto Expo (alternativa)
branding/logo.svg  logo vetorial (fonte dos ícones)
scripts/           build-config.mjs (variáveis de ambiente) e make-icons.mjs
tests/             e2e.py, mock-server.mjs, mock-supabase.js
docs/              INTEGRACOES.md, SETUP-CELULAR.md, BANCO-DE-DADOS.md, IDENTIDADE-VISUAL.md
```

## Rodar localmente
```bash
npm run serve            # abre http://localhost:8080
python3 tests/e2e.py     # 33 testes (sobe um Supabase simulado sozinho; requer playwright)
```

## Variáveis de ambiente (Netlify > Site configuration > Environment variables)
`SUPABASE_URL`, `SUPABASE_PUBLISHABLE_KEY`, `SITE_URL`, `SENTRY_DSN` — todas **públicas**. Veja `.env.example`.
O build (`scripts/build-config.mjs`) grava esses valores em `public/config.js`.
**Nunca** commit de `service_role`, senhas ou tokens.

## Regras do app
- Cada usuário só acessa os próprios dados (RLS em todas as tabelas).
- Nome de exibição (até 40) e @ (3–24 caracteres, aceita espaços, símbolos e emojis): **2 alterações; depois, pausa de 30 dias**. A regra roda no servidor (`save_profile`).
- Sessão mantida ao atualizar a página (F5); funciona offline e sincroniza quando a internet volta.

Leia `docs/INTEGRACOES.md` para o estado de cada serviço e `docs/SETUP-CELULAR.md` para o que fazer pelo celular.
