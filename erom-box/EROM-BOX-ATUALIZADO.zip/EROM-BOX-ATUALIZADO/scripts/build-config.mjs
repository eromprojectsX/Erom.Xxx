// Gera public/config.js a partir de variáveis de ambiente (Netlify > Site configuration > Environment variables).
// Se nenhuma variável existir, mantém o config.js do repositório. Só valores PÚBLICOS entram aqui.
import { readFileSync, writeFileSync } from 'node:fs';
const file = new URL('../public/config.js', import.meta.url);
const env = process.env;
const map = {
  SUPABASE_URL: env.SUPABASE_URL,
  SUPABASE_PUBLISHABLE_KEY: env.SUPABASE_PUBLISHABLE_KEY,
  SITE_URL: env.SITE_URL || env.URL,
  SENTRY_DSN: env.SENTRY_DSN,
};
if (!Object.values(map).some(Boolean)) { console.log('build-config: sem variáveis de ambiente; mantendo public/config.js'); process.exit(0); }
if (/service_role|sb_secret_/i.test(JSON.stringify(map))) { console.error('ERRO: chave secreta detectada. Use apenas a chave publishable/anon.'); process.exit(1); }
const cur = readFileSync(file, 'utf8');
const pick = (k) => (cur.match(new RegExp(k + ":\\s*'([^']*)'")) || [, ''])[1];
const out = Object.fromEntries(Object.keys(map).map((k) => [k, map[k] || pick(k)]));
writeFileSync(file, `/* Gerado por scripts/build-config.mjs — valores públicos */\nwindow.EROM_CONFIG = ${JSON.stringify(out, null, 2)};\n`);
console.log('build-config: config.js atualizado com variáveis de ambiente');
