// Gera os ícones PNG (PWA/APK) a partir de branding/logo.svg. Não derruba o build se falhar.
import { mkdirSync, existsSync } from 'node:fs';
try {
  const sharp = (await import('sharp')).default;
  const src = new URL('../branding/logo.svg', import.meta.url).pathname;
  const out = new URL('../public/icons/', import.meta.url).pathname;
  mkdirSync(out, { recursive: true });
  const png = (n, s) => sharp(src, { density: 300 }).resize(s, s).png().toFile(out + n);
  await Promise.all([png('icon-192.png', 192), png('icon-512.png', 512), png('apple-touch-icon.png', 180), png('favicon-32.png', 32)]);
  await sharp(src, { density: 300 }).resize(410, 410).extend({ top: 51, bottom: 51, left: 51, right: 51, background: '#000' }).png().toFile(out + 'icon-maskable-512.png');
  console.log('make-icons: ok');
} catch (e) {
  console.warn('make-icons: ignorado (' + e.message + '). Os ícones já versionados continuam valendo.');
  if (!existsSync(new URL('../public/icons/icon-512.png', import.meta.url).pathname)) console.warn('Aviso: public/icons/icon-512.png não existe.');
}
