# Identidade visual — EROM BOX

- **Logo:** monograma "EB" com o botão de play e uma fita de filme que envolve a letra B; abaixo, "EROM" e "BOX". Fonte vetorial: `branding/logo.svg`. Modelos: **prateado** (padrão) e **dourado** (Perfil > Logo).
- **Abertura:** a logo é desenhada traço a traço e preenchida; a fita de filme anima; dura **3,8 s** (site, app e APK). Replay em Perfil > Logo > "Ver abertura".
- **Fundo da marca:** `#000000` · **tema escuro do app:** `#080a0f`.
- **Prata:** `#fdfdfd → #c4c4c4` · **Dourado:** `#fff4c6 → #f4cb62 → #d6a02f → #a5701a`.
- **Cores de destaque do app:** Prata `#b8c4d8`, Verde `#35d07f`, Azul `#5ba7ff`, Roxo `#b28aff`, Vermelho `#ff6574`, Rosa `#ff83c6`, Laranja `#ffad5a`, Ciano `#51d9df`.
- **Ícones PWA/APK:** `public/icons/` e `mobile/assets/` (gerados de `branding/logo.svg` pelos scripts `make-icons` / `make-assets`).

- **Figma:** https://www.figma.com/design/cIp65tAo1GJFU7RAIwWUAj (estilos de cor, logos e paletas).
