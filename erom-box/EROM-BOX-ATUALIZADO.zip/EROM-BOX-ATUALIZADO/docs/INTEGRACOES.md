# Relatório de integrações

Legenda: ✅ concluído e verificado · 🟡 pronto, falta ação sua · ⚪ não usado (decisão) · ❌ não foi possível

## Arquitetura escolhida (sem serviços duplicados)
**Netlify** (site) + **Supabase** (login, banco, RLS, função) + **Sentry** (erros) + **GitHub** (código) + **Expo** (APK) + **Linear** (tarefas).

| Conector | Status | O que foi feito de verdade | O que falta / observação |
|---|---|---|---|
| **Supabase** | ✅ | Migração aplicada (`profiles`, `library_items`, RLS, `save_profile`, gatilho de perfil, cascata, limite 800 itens). 23 testes de segurança passaram no banco real. Edge Function `delete-account` v3 publicada. Políticas da tabela antiga otimizadas. | 🟡 Cadastrar **Redirect URLs** e (se o plano permitir) ligar **senhas vazadas**; SMTP próprio para e-mails em produção. |
| **Netlify** | 🟡 | Site `erombox` já existia. 4 variáveis de ambiente públicas configuradas (build). | ❌ **Não publiquei**: o deploy só roda pela CLI com internet. 🟡 O site exige login do time Netlify (acesso restrito) — liberar após publicar. Veja `SETUP-CELULAR.md`. |
| **GitHub** | 🟡 | Conector é **somente leitura** (erro 403 ao criar repositório e ao enviar arquivos): nada foi enviado por mim. Preparei `apk-github/` (ZIP Android + fluxo) no método que você já usa no EromMusic. | Você sobe o código/ZIP pelo celular; veja `SETUP-CELULAR.md`. |
| **Expo** | 🟡 | Alternativa: projeto em `mobile/` (WebView, botão voltar, offline, exportar backup), `eas.json` (perfil `preview` = APK) e workflow EAS. | ❌ **APK não compilado**: exige `eas init` com login na sua conta e GitHub conectado. |
| **Sentry** | ✅ | Projeto `erombox-web` criado na organização `erom`; DSN no `config.js`; SDK carregado só com DSN, sem e-mail/IP. | Opcional: limitar eventos por hora no DSN para proteger a cota gratuita. |
| **Linear** | ✅ | Projeto "EROM BOX" e 8 tarefas (2 concluídas, 6 pendentes) no time Erom. | — |
| **Figma** | ✅ | Arquivo "EROM BOX — Identidade Visual" criado na sua equipe: 24 estilos de cor (marca, app claro/escuro e 8 cores de destaque), logo prateada e dourada em vetor, paletas e descrição da abertura de 3,8 s. Link: https://www.figma.com/design/cIp65tAo1GJFU7RAIwWUAj | Seu assento no Figma é "View" (plano Starter): o arquivo foi criado, mas você pode precisar de assento de edição para alterá-lo. |
| **Cloudflare** | ⚪ | Não usado: duplicaria a hospedagem do Netlify. | — |
| **Neon** | ⚪ | Não usado: o banco já é o Postgres do Supabase; dois bancos seriam custo e complexidade à toa. | — |
| **BigQuery** | ⚪ | Não usado: sem necessidade de análises; evita copiar dados dos usuários para outro serviço. | — |
| **Lovable** | ⚪ | Não usado: geraria um projeto separado, duplicando o app. | — |

## Limites e custos (referência — confira nos sites, planos mudam)
- **Supabase gratuito:** ~500 MB de banco, 1 GB de arquivos, ~50 mil usuários ativos/mês; projetos inativos podem ser pausados; e-mail padrão tem limite baixo (use SMTP próprio). O app limita **800 itens por usuário** e pôsteres a ~140 KB.
- **Netlify:** o site estático cabe no plano gratuito; builds e banda têm cota mensal.
- **Sentry:** plano gratuito com cota mensal pequena de erros (por isso erros de rede são ignorados).
- **Expo/EAS:** plano gratuito com número limitado de builds por mês e fila lenta.
- **GitHub / Linear:** repositório privado e projeto simples cabem nos planos gratuitos.

## Segurança
- Só a chave **publishable** do Supabase está no código (pública por natureza; quem protege é o RLS).
- A `service_role` existe apenas dentro da Edge Function (variável automática do Supabase).
- Removida do código a senha de teste do "modo desenvolvedor local" que estava no HTML. O e-mail de desenvolvedor segue o fluxo normal de cadastro e **não** tem modo especial.
- Dados locais são apagados ao sair da conta e nunca se misturam entre contas no mesmo aparelho.
- Cabeçalhos de segurança (CSP etc.) em `netlify.toml`, testados.

## Testes
- Banco real: 23 verificações (isolamento entre usuários, regras de perfil, anônimo bloqueado, cascata) — transação desfeita.
- App: 33 testes ponta a ponta contra um Supabase **simulado** (`tests/`). Não foram executados contra o Supabase real, nem num celular físico, nem o APK.
