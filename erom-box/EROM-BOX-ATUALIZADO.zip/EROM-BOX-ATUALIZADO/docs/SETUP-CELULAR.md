# O que fazer pelo celular (na ordem)

## 1) Supabase — 2 minutos (supabase.com > projeto "Erom Projects")
1. **Authentication > URL Configuration**: Site URL `https://erombox.netlify.app` e, em Redirect URLs, `https://erombox.netlify.app/**`.
2. **Authentication > Sign In / Providers > Email > Password security**: ligar *Leaked password protection* (se o plano permitir).
3. (Produção) **Authentication > Emails > SMTP Settings**: configurar um SMTP próprio.
4. Para o seu usuário de desenvolvimento: cadastre-se normalmente no app com o e-mail desejado e uma senha forte sua.

## 2) Publicar o site (Netlify, projeto `erombox`)
**Opção A — pelo GitHub (recomendada):** app.netlify.com > projeto `erombox` > *Project configuration > Build & deploy > Link repository* > GitHub > `erom-box`. Build command e pasta já vêm do `netlify.toml`.
**Opção B — enviar a pasta:** app.netlify.com > *Deploys* > arrastar/enviar o conteúdo da pasta `public/` (o ZIP do projeto traz a pasta pronta).
Depois: **Project configuration > Access & security > Visitor access** → desligar o login obrigatório do time, para qualquer pessoa abrir o site.
Teste: abra `https://erombox.netlify.app`, veja a abertura de 3,8 s, crie uma conta de teste e entre.

## 3) Instalar como app (sem APK)
Android/Chrome: menu ⋮ > *Instalar app*. iPhone/Safari: Compartilhar > *Adicionar à Tela de Início*.

## 4) Código no GitHub e APK pelo celular (GitHub Actions)
Na pasta `apk-github/` do ZIP há 2 ZIPs e 2 fluxos. Tudo vai para o repositório pelo site do GitHub:
1. **Criar a pasta:** *Add file → Create new file*, nome `erom-box/README.md`, escreva `EROM BOX` e confirme.
2. **Enviar os ZIPs:** abra a pasta `erom-box` > *Add file → Upload files* e envie `EROM-BOX-ATUALIZADO.zip` e `EromBox-Android-Studio.zip`.
3. **Criar os fluxos:** *Add file → Create new file* com os nomes `.github/workflows/unpack-erombox-code.yml` e `.github/workflows/build-erombox-apk.yml`, colando o conteúdo dos arquivos de mesmo nome.
4. O fluxo *Unpack EROM BOX code* descompacta e organiza o código em `erom-box/src/` sozinho. Se não rodar, vá em **Actions → Unpack EROM BOX code → Run workflow**.
5. **Actions → Build EROM BOX APK → Run workflow** (5–15 min). Baixe **EROM-BOX-APK** em *Artifacts*; dentro está o `.apk`.
O APK abre o endereço definido em `android/app/src/main/res/values/strings.xml` (`site_url`). O conector do Claude para o GitHub só lê; por isso o envio é feito por você.

## 5) Opção alternativa: Expo/EAS (`mobile/`)
Requer computador ou Codespaces: `cd mobile && npx expo install --fix && npm i -g eas-cli && eas login && eas init && eas build -p android --profile preview`.
Outra alternativa: https://www.pwabuilder.com com o endereço do site > Android.
