# Banco de dados (Supabase / PostgreSQL)

Migração: `supabase/migrations/20261012000100_erom_box_core.sql` (já aplicada no projeto `xpycuphgsbmydertxyff`).
Para um projeto novo: abra *SQL Editor*, cole o arquivo e execute. É seguro reaplicar.

## Tabelas
- `profiles` (1 por usuário): `username`, `display_name`, `avatar`, `banner`, `settings` (tema, cor, logo), `change_count`, `last_change_at`.
- `library_items` (1 por filme/série/desenho): `kind` (Filme/Série/Desenho), `collection` (library/upcoming), `title`, `data` (temporadas, episódios, progresso…), `poster`, `updated_ms`, `deleted` (lápide para sincronizar exclusões).
- `erom_user_data`: tabela antiga (1 linha/usuário). Mantida sem uso; pode ser apagada depois de conferir que não precisa dos dados.

## Segurança (RLS)
Todas as tabelas têm RLS: `user_id = (select auth.uid())` para ler, inserir, alterar e apagar. `anon` não acessa nada.
`username`, `display_name` e os contadores **não** podem ser alterados direto pela API (permissão só em `avatar`, `banner`, `settings`); só a função `save_profile` altera, aplicando a regra:
- nome obrigatório (≤ 40); @ com 3–24 caracteres (espaços, símbolos e emojis valem);
- cada troca de nome **ou** @ conta 1; ao chegar em 2, nova troca só após 30 dias da última;
- sem mudança real, não consome alteração; o @ definido no cadastro não conta.

## Exclusão da conta
Edge Function `delete-account` (`supabase/functions/delete-account/index.ts`): valida o token do usuário e apaga o usuário no Auth; `profiles` e `library_items` caem em cascata.
Deploy: `supabase functions deploy delete-account --no-verify-jwt` (a validação é feita dentro da função).

## Limites
800 itens por usuário; pôster ≤ 150 000 caracteres; avatar ≤ 200 000; banner ≤ 400 000; `data` ≤ 60 KB; lápides com mais de 90 dias são limpas pelo app.

## Cadastro sem confirmação de e-mail
Migração `20261013000200_auto_confirm_email.sql`: o gatilho `auto_confirm_email_trg` marca o e-mail como confirmado ao criar a conta, e o app entra direto após o cadastro (usuário + e-mail + senha). Já aplicada no projeto.
Recomendado também desligar *Authentication > Sign In / Providers > Email > Confirm email* no painel: assim o Supabase nem tenta enviar e-mail (o envio padrão tem limite baixo por hora).
Atenção: sem confirmação, qualquer pessoa pode cadastrar o e-mail de outra; para voltar a exigir, apague o gatilho (comando no topo do arquivo SQL).
