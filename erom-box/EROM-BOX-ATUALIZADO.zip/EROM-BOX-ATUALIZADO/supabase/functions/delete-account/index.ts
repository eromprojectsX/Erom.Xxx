import { createClient } from "npm:@supabase/supabase-js@2";

// Exclusão segura da PRÓPRIA conta.
// - O token do usuário é validado no Auth do Supabase (a chave de administrador fica só aqui, no servidor).
// - Ao apagar o usuário, profiles e library_items são apagados em cascata (ON DELETE CASCADE).
// Publicada com verify_jwt = false porque a validação é feita dentro da função (auth.getUser).
const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), {
    status,
    headers: { ...cors, "Content-Type": "application/json" },
  });

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  if (req.method !== "POST") return json({ error: "Método não permitido" }, 405);

  const token = (req.headers.get("Authorization") ?? "").replace(/^Bearer\s+/i, "").trim();
  if (!token) return json({ error: "Não autorizado" }, 401);

  const admin = createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
    { auth: { persistSession: false, autoRefreshToken: false } },
  );

  const { data: { user }, error } = await admin.auth.getUser(token);
  if (error || !user) return json({ error: "Não autorizado" }, 401);

  const { error: delErr } = await admin.auth.admin.deleteUser(user.id);
  if (delErr) return json({ error: delErr.message }, 500);

  return json({ success: true });
});
