-- Cadastro sem confirmação por e-mail: a conta nasce confirmada e o usuário entra direto.
-- Para voltar a exigir confirmação: drop trigger auto_confirm_email_trg on auth.users;
create or replace function public.auto_confirm_email()
returns trigger language plpgsql security definer set search_path = '' as $$
begin
  if new.email is not null and new.email_confirmed_at is null then
    new.email_confirmed_at := now();
  end if;
  return new;
end $$;
revoke all on function public.auto_confirm_email() from public, anon, authenticated;

drop trigger if exists auto_confirm_email_trg on auth.users;
create trigger auto_confirm_email_trg before insert on auth.users
  for each row execute function public.auto_confirm_email();
