-- =====================================================================
-- EROM BOX — esquema principal (Supabase / PostgreSQL)
-- Cada usuário só enxerga e altera os PRÓPRIOS dados (RLS em todas as tabelas).
-- Seguro para reaplicar: usa IF NOT EXISTS / CREATE OR REPLACE.
-- =====================================================================

-- ---------- 1) PERFIL (nome de exibição, @usuário, avatar, banner, preferências) ----------
create table if not exists public.profiles (
  user_id        uuid primary key references auth.users (id) on delete cascade,
  username       text        not null default 'usuario',
  display_name   text        not null default 'Usuário EROM',
  avatar         text,
  banner         text,
  settings       jsonb       not null default '{}'::jsonb,
  change_count   smallint    not null default 0,      -- alterações de nome/@ usadas (máx. 2 por ciclo)
  last_change_at timestamptz,                         -- início da pausa de 30 dias
  created_at     timestamptz not null default now(),
  updated_at     timestamptz not null default now(),
  constraint profiles_username_len   check (char_length(username) between 3 and 24),
  constraint profiles_display_len    check (char_length(btrim(display_name)) between 1 and 40),
  constraint profiles_avatar_size    check (avatar is null or length(avatar) <= 200000),
  constraint profiles_banner_size    check (banner is null or length(banner) <= 400000),
  constraint profiles_settings_obj   check (jsonb_typeof(settings) = 'object' and pg_column_size(settings) <= 20000)
);

create or replace function public.set_updated_at()
returns trigger language plpgsql set search_path = '' as $$
begin new.updated_at := now(); return new; end $$;

drop trigger if exists profiles_set_updated_at on public.profiles;
create trigger profiles_set_updated_at before update on public.profiles
  for each row execute function public.set_updated_at();

alter table public.profiles enable row level security;

drop policy if exists "profiles_select_own" on public.profiles;
create policy "profiles_select_own" on public.profiles
  for select to authenticated using (user_id = (select auth.uid()));

drop policy if exists "profiles_update_own" on public.profiles;
create policy "profiles_update_own" on public.profiles
  for update to authenticated
  using (user_id = (select auth.uid())) with check (user_id = (select auth.uid()));

-- Nome/@/contadores NÃO podem ser alterados direto pela API: só pela função save_profile().
revoke all on public.profiles from anon, authenticated;
grant select on public.profiles to authenticated;
grant update (avatar, banner, settings) on public.profiles to authenticated;

-- Cria o perfil automaticamente quando a conta é criada (o @ inicial NÃO conta como alteração).
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = '' as $$
declare u text := btrim(regexp_replace(coalesce(new.raw_user_meta_data ->> 'username', ''), '^@+', ''));
begin
  if char_length(u) < 3 or char_length(u) > 24 then u := 'usuario'; end if;
  insert into public.profiles (user_id, username, display_name)
  values (new.id, u, left(u, 40))
  on conflict (user_id) do nothing;
  return new;
end $$;
revoke all on function public.handle_new_user() from public, anon, authenticated;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();

-- Perfis para contas que já existiam antes desta migração.
insert into public.profiles (user_id, username, display_name)
select u.id,
       case when char_length(btrim(regexp_replace(coalesce(u.raw_user_meta_data ->> 'username',''), '^@+',''))) between 3 and 24
            then btrim(regexp_replace(u.raw_user_meta_data ->> 'username', '^@+', '')) else 'usuario' end,
       case when char_length(btrim(regexp_replace(coalesce(u.raw_user_meta_data ->> 'username',''), '^@+',''))) between 3 and 24
            then left(btrim(regexp_replace(u.raw_user_meta_data ->> 'username', '^@+', '')), 40) else 'Usuário EROM' end
from auth.users u
on conflict (user_id) do nothing;

-- Regras de alteração (iguais às do app): 3–24 caracteres no @, nome obrigatório (até 40);
-- cada troca de nome OU @ conta 1; após 2 trocas, nova troca só depois de 30 dias da última.
create or replace function public.save_profile(p_display_name text, p_username text)
returns public.profiles
language plpgsql security definer set search_path = '' as $$
declare
  uid     uuid := auth.uid();
  prof    public.profiles;
  v_name  text := btrim(coalesce(p_display_name, ''));
  v_user  text := btrim(regexp_replace(coalesce(p_username, ''), '^@+', ''));
  v_count int;
  v_days  int;
begin
  if uid is null then
    raise exception 'Faça login para alterar o perfil.' using errcode = '28000';
  end if;
  if v_name = '' then
    raise exception 'Digite um nome de exibição.' using errcode = '22023';
  end if;
  if char_length(v_name) > 40 then
    raise exception 'O nome de exibição pode ter no máximo 40 caracteres.' using errcode = '22023';
  end if;
  if char_length(v_user) < 3 or char_length(v_user) > 24 then
    raise exception 'O @ do usuário deve ter de 3 a 24 caracteres. Pode usar espaços, letras, números, símbolos e emojis.' using errcode = '22023';
  end if;

  select * into prof from public.profiles where user_id = uid for update;
  if not found then
    insert into public.profiles (user_id, username, display_name) values (uid, v_user, v_name)
    returning * into prof;
    return prof;
  end if;

  if v_name = prof.display_name and v_user = prof.username then
    return prof;                                   -- nada mudou: não consome alteração
  end if;

  v_count := prof.change_count;
  if v_count >= 2 then
    if prof.last_change_at is not null and now() < prof.last_change_at + interval '30 days' then
      v_days := ceil(extract(epoch from (prof.last_change_at + interval '30 days' - now())) / 86400)::int;
      raise exception 'Você já usou as 2 alterações. Poderá alterar o nome de exibição e o @ novamente em % dia(s).', v_days
        using errcode = 'P0001';
    end if;
    v_count := 0;                                  -- pausa terminou: novo ciclo
  end if;

  update public.profiles
     set display_name = v_name, username = v_user,
         change_count = v_count + 1, last_change_at = now()
   where user_id = uid
   returning * into prof;
  return prof;
end $$;
revoke all on function public.save_profile(text, text) from public, anon;
grant execute on function public.save_profile(text, text) to authenticated;

-- ---------- 2) BIBLIOTECA (um registro por filme/série/desenho) ----------
create table if not exists public.library_items (
  user_id     uuid        not null default auth.uid() references auth.users (id) on delete cascade,
  id          uuid        not null,
  kind        text        not null check (kind in ('Filme', 'Série', 'Desenho')),
  collection  text        not null default 'library' check (collection in ('library', 'upcoming')),
  title       text        not null default '',
  data        jsonb       not null default '{}'::jsonb,   -- demais campos (temporadas, episódios, progresso…)
  poster      text,                                       -- imagem reduzida (data URL) ou link
  updated_ms  bigint      not null default (extract(epoch from now()) * 1000)::bigint,
  deleted     boolean     not null default false,         -- "lápide": permite sincronizar exclusões entre aparelhos
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now(),
  primary key (user_id, id),
  constraint library_title_len  check (deleted or char_length(title) between 1 and 200),
  constraint library_data_size  check (jsonb_typeof(data) = 'object' and pg_column_size(data) <= 60000),
  constraint library_poster_len check (poster is null or length(poster) <= 150000)
);
create index if not exists library_items_user_updated_idx on public.library_items (user_id, updated_ms);

drop trigger if exists library_items_set_updated_at on public.library_items;
create trigger library_items_set_updated_at before update on public.library_items
  for each row execute function public.set_updated_at();

-- Limite por usuário (protege o plano gratuito contra abuso).
create or replace function public.library_items_limit()
returns trigger language plpgsql security definer set search_path = '' as $$
begin
  if (select count(*) from public.library_items where user_id = new.user_id) >= 800 then
    raise exception 'Limite de 800 itens por biblioteca atingido.' using errcode = 'P0001';
  end if;
  return new;
end $$;
revoke all on function public.library_items_limit() from public, anon, authenticated;

drop trigger if exists library_items_limit_trg on public.library_items;
create trigger library_items_limit_trg before insert on public.library_items
  for each row execute function public.library_items_limit();

alter table public.library_items enable row level security;

drop policy if exists "library_select_own" on public.library_items;
create policy "library_select_own" on public.library_items
  for select to authenticated using (user_id = (select auth.uid()));
drop policy if exists "library_insert_own" on public.library_items;
create policy "library_insert_own" on public.library_items
  for insert to authenticated with check (user_id = (select auth.uid()));
drop policy if exists "library_update_own" on public.library_items;
create policy "library_update_own" on public.library_items
  for update to authenticated
  using (user_id = (select auth.uid())) with check (user_id = (select auth.uid()));
drop policy if exists "library_delete_own" on public.library_items;
create policy "library_delete_own" on public.library_items
  for delete to authenticated using (user_id = (select auth.uid()));

revoke all on public.library_items from anon, authenticated;
grant select, insert, update, delete on public.library_items to authenticated;

-- ---------- 3) TABELA ANTIGA (erom_user_data): mesma segurança, mais rápida ----------
alter policy "Users can read own Erom Box data"   on public.erom_user_data using ((select auth.uid()) = user_id);
alter policy "Users can insert own Erom Box data" on public.erom_user_data with check ((select auth.uid()) = user_id);
alter policy "Users can update own Erom Box data" on public.erom_user_data
  using ((select auth.uid()) = user_id) with check ((select auth.uid()) = user_id);
alter policy "Users can delete own Erom Box data" on public.erom_user_data using ((select auth.uid()) = user_id);
revoke all on public.erom_user_data from anon;
