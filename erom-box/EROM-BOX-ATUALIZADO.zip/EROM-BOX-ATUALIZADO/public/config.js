/* Configuração PÚBLICA do EROM BOX (sem segredos).
   A chave "publishable" do Supabase é feita para ficar no navegador: quem protege os dados é o RLS.
   NUNCA coloque aqui a service_role, senhas ou chaves privadas.
   No Netlify, as variáveis de ambiente abaixo sobrescrevem estes valores durante o build (scripts/build-config.mjs). */
window.EROM_CONFIG = {
  SUPABASE_URL: 'https://xpycuphgsbmydertxyff.supabase.co',
  SUPABASE_PUBLISHABLE_KEY: 'sb_publishable_piAuc_6FnnnXCeI_3Yf7YQ_Ez2a3Gh4',
  SITE_URL: 'https://erombox.netlify.app',
  SENTRY_DSN: 'https://aced4871ee2eaa2efece32ab48510941@o4512244954628096.ingest.us.sentry.io/4512247117905920'
};
