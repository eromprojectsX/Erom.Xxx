/* EROM BOX — service worker: abre rápido e funciona sem internet com os dados já salvos.
   Nunca guarda chamadas ao Supabase (login e dados). Aumente VERSION a cada publicação. */
const VERSION = 'erombox-v4';
const SHELL = [
  './', './index.html', './config.js', './manifest.webmanifest',
  './assets/app.css', './assets/logo.js', './assets/app.js', './assets/cloud.js', './assets/monitoring.js',
  './assets/android-bridge.js', './assets/install.js', './assets/register-sw.js',
  './icons/icon-192.png', './icons/icon-512.png', './icons/icon-maskable-512.png', './icons/apple-touch-icon.png', './icons/favicon-32.png'
];
self.addEventListener('install', e => {
  e.waitUntil(caches.open(VERSION).then(c => c.addAll(SHELL)).then(() => self.skipWaiting()));
});
self.addEventListener('activate', e => {
  e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k !== VERSION).map(k => caches.delete(k)))).then(() => self.clients.claim()));
});
self.addEventListener('fetch', e => {
  const req = e.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);
  if (url.hostname.endsWith('.supabase.co') || url.hostname.endsWith('sentry.io') || url.hostname.endsWith('sentry-cdn.com')) return;
  const mine = url.origin === location.origin;
  const cdn = url.href.startsWith('https://cdn.jsdelivr.net/');
  if (!mine && !cdn) return;
  e.respondWith(
    caches.match(req, { ignoreSearch: true }).then(hit => {
      const net = fetch(req).then(r => {
        if (r && (r.ok || r.type === 'opaque')) { const cp = r.clone(); caches.open(VERSION).then(c => c.put(req, cp)); }
        return r;
      }).catch(() => hit || (req.mode === 'navigate' ? caches.match('./index.html') : Response.error()));
      return hit || net;
    })
  );
});
