/* EROM BOX — monitoramento de erros (Sentry, plano gratuito). Só ativa se SENTRY_DSN estiver em config.js.
   Não envia e-mail, IP nem cookies. Erros de rede/offline são ignorados. */
(function(){
  var dsn=(window.EROM_CONFIG||{}).SENTRY_DSN;
  var m=dsn&&/^https:\/\/([a-f0-9]+)@[^/]+\/\d+$/.exec(dsn);
  if(!m)return;
  window.sentryOnLoad=function(){
    try{
      Sentry.init({
        dsn:dsn,
        environment:/^(localhost|127\.)/.test(location.hostname)?'development':'production',
        sendDefaultPii:false,
        tracesSampleRate:0,
        ignoreErrors:['ResizeObserver loop limit exceeded','ResizeObserver loop completed with undelivered notifications.','Failed to fetch','NetworkError','Load failed','Network request failed'],
        beforeSend:function(ev){
          if(ev.request){delete ev.request.cookies;delete ev.request.headers}
          if(ev.user){delete ev.user.email;delete ev.user.ip_address;delete ev.user.username}
          return ev}
      });
    }catch(e){}
  };
  var s=document.createElement('script');
  s.src='https://js.sentry-cdn.com/'+m[1]+'.min.js';s.crossOrigin='anonymous';s.async=true;
  document.head.appendChild(s);
})();
