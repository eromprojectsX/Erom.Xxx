/* Modo Android (WebView): sem seletor de arquivos nem download nativo -> alternativas por texto/URL */
(function(){
if(typeof AndroidApp==='undefined')return;
var back=document.createElement('div');back.className='modal-back';back.id='txtBack';
back.innerHTML='<div class="modal"><div class="modal-head"><h2 id="txtTitle"></h2><button class="btn" id="txtClose">✕</button></div><p class="muted" id="txtHelp"></p><textarea class="field" id="txtArea" rows="10" style="width:100%;font-size:12px"></textarea><div class="modal-actions"><button class="btn" id="txtCopy">Copiar tudo</button><button class="btn primary" id="txtGo">Importar</button></div></div>';
document.body.appendChild(back);
var A=function(i){return document.getElementById(i)};
A('txtClose').onclick=function(){back.classList.remove('open')};
function openTxt(mode){
 A('txtTitle').textContent=mode==='exp'?'Backup da biblioteca':'Importar backup';
 A('txtHelp').textContent=mode==='exp'?'Toque em "Copiar tudo" e cole o texto em um lugar seguro (notas, e-mail, WhatsApp para você mesmo).':'Cole aqui o texto do backup copiado anteriormente.';
 A('txtArea').value=mode==='exp'?JSON.stringify({app:'Erom Box',version:1,exportedAt:new Date().toISOString(),items:items,settings:settings},null,2):'';
 A('txtCopy').style.display=mode==='exp'?'':'none';A('txtGo').style.display=mode==='exp'?'none':'';
 back.classList.add('open');
}
A('txtCopy').onclick=function(){var t=A('txtArea');t.focus();t.select();var ok=false;try{ok=document.execCommand('copy')}catch(e){}toast(ok?'Backup copiado.':'Selecione o texto e copie manualmente.')};
A('txtGo').onclick=function(){var v=A('txtArea').value.trim();if(!v){toast('Cole o backup primeiro.');return}back.classList.remove('open');importData(new Blob([v]))};
A('exportBtn').onclick=A('profileExport').onclick=function(){openTxt('exp')};
A('importBtn').onclick=function(){openTxt('imp')};
var pf=A('posterFile');pf.style.display='none';
var u=document.createElement('input');u.type='url';u.className='field';u.id='posterUrl';u.placeholder='Link (URL) da imagem do pôster';pf.parentNode.insertBefore(u,pf);
pf.parentNode.querySelector('small').textContent='Cole o link de uma imagem de pôster (precisa de internet para exibir).';
u.addEventListener('input',function(){editingPoster=u.value.trim()||null});
var o=window.openForm;window.openForm=function(id){o(id);u.value=(editingPoster&&editingPoster.indexOf('data:')!==0)?editingPoster:''};
})();
