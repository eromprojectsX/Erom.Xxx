/* EROM BOX — autenticação real (Supabase Auth) + sincronização privada por usuário.
   - Biblioteca: uma linha por item em public.library_items (RLS: cada usuário só vê o que é seu).
   - Perfil/preferências: public.profiles. Nome e @ só mudam pela função save_profile (regra 2x / 30 dias).
   - Funciona offline: os dados ficam no aparelho e são enviados quando a conexão volta. */
(function(){
'use strict';
const CFG=window.EROM_CONFIG||{};
const SUPABASE_URL=CFG.SUPABASE_URL, SUPABASE_KEY=CFG.SUPABASE_PUBLISHABLE_KEY;
const SITE_URL=(CFG.SITE_URL||'').replace(/\/*$/,'/');
const META='erombox-sync-v2:', LAST_UID='erombox-last-uid';
const $id=id=>document.getElementById(id);
let client=null,mode='login',recovery=/type=recovery/.test(location.hash+location.search);
let cloudReady=false,uid=null,entering=false,pushing=false,pushAgain=false,timer=null,lastPull=0;
const gate=$id('authGate'),msg=$id('authMessage');

/* ---------- interface de login ---------- */
function message(t,err=false){msg.textContent=t;msg.style.color=err?'var(--red)':'var(--accent)'}
function setMode(m){mode=m;
  $id('authHeading').textContent=m==='recovery'?'Definir nova senha':m==='signup'?'Criar sua conta':m==='reset'?'Recuperar senha':'Entre na sua conta';
  $id('authIntro').textContent=m==='recovery'?'Digite a nova senha para concluir a recuperação da sua conta.':m==='signup'?'Crie uma conta para manter seus dados sincronizados.':m==='reset'?'Enviaremos um link de recuperação para seu e-mail.':'Entre para acessar sua biblioteca sincronizada.';
  $id('signupNameWrap').style.display=m==='signup'?'':'none';
  $id('authPasswordWrap').style.display=m==='reset'?'none':'';
  $id('authSubmit').textContent=m==='recovery'?'Salvar nova senha':m==='signup'?'Criar conta':m==='reset'?'Enviar link':'Entrar';
  $id('authForgot').style.display=(m==='reset'||m==='recovery')?'none':'';
  $id('authEmail').parentNode.style.display=m==='recovery'?'none':'';
  document.querySelector('.auth-switch').style.display=m==='recovery'?'none':'';
  $id('authPassword').autocomplete=(m==='signup'||m==='recovery')?'new-password':'current-password';
  message('')}
function showGate(){document.body.classList.remove('authenticated');gate.classList.add('show')}
function hideGate(){gate.classList.remove('show');document.body.classList.add('authenticated')}
function friendly(e){let t=(e&&e.message)||'Não foi possível concluir a operação.';
  if(/invalid login credentials/i.test(t))return 'E-mail ou senha incorretos.';
  if(/email not confirmed/i.test(t))return 'Não foi possível entrar agora. Tente novamente em instantes.';
  if(/email rate limit/i.test(t))return 'Muitos cadastros seguidos. Aguarde alguns minutos e tente de novo.';
  if(/user already registered/i.test(t))return 'Este e-mail já possui uma conta.';
  if(/different from the old password/i.test(t))return 'A nova senha precisa ser diferente da anterior.';
  if(/weak|pwned|leaked|password should contain/i.test(t))return 'Escolha uma senha mais forte (mínimo 8 caracteres).';
  if(/rate limit|too many/i.test(t))return 'Muitas tentativas. Aguarde alguns minutos e tente de novo.';
  if(/failed to fetch|networkerror|load failed/i.test(t))return 'Falha de conexão. Confira sua internet.';
  return t}
function isNetwork(e){return !navigator.onLine||/failed to fetch|networkerror|load failed|network request failed/i.test(String(e&&e.message||''))}
function status(t){const n=$id('accountNote');if(n)n.textContent=t}
function hhmm(){return new Date().toLocaleTimeString('pt-BR',{hour:'2-digit',minute:'2-digit'})}

/* ---------- utilidades de sincronização ---------- */
function stable(o){if(Array.isArray(o))return '['+o.map(stable).join(',')+']';if(o&&typeof o==='object')return '{'+Object.keys(o).sort().map(k=>JSON.stringify(k)+':'+stable(o[k])).join(',')+'}';return JSON.stringify(o===undefined?null:o)}
function hash(str){let h1=0xdeadbeef,h2=0x41c6ce57;for(let i=0;i<str.length;i++){const c=str.charCodeAt(i);h1=Math.imul(h1^c,2654435761);h2=Math.imul(h2^c,1597334677)}h1=Math.imul(h1^(h1>>>16),2246822507)^Math.imul(h2^(h2>>>13),3266489909);h2=Math.imul(h2^(h2>>>16),2246822507)^Math.imul(h1^(h1>>>13),3266489909);return (4294967296*(2097151&h2)+(h1>>>0)).toString(36)}
function hashItem(it){const c={...it};delete c.updated;return hash(stable(c))}
function loadMeta(){try{const m=JSON.parse(localStorage.getItem(META+uid)||'{}');return {map:m.map||{},prof:m.prof||{},dirty:!!m.dirty}}catch{return {map:{},prof:{},dirty:false}}}
function saveMeta(m){try{localStorage.setItem(META+uid,JSON.stringify(m))}catch{}}
function toRow(it){const {poster,...rest}=it;return {user_id:uid,id:it.id,kind:it.kind,collection:it.collection==='upcoming'?'upcoming':'library',title:String(it.title||'').slice(0,200),data:rest,poster:poster||null,updated_ms:Number(it.updated)||Number(it.created)||Date.now(),deleted:false}}
function fromRow(r){const d=r.data&&typeof r.data==='object'?r.data:{};return {...d,id:r.id,kind:r.kind,collection:r.collection,title:r.title,poster:r.poster||null,updated:Number(r.updated_ms)||d.updated||0}}
function wipeLocal(){items=[];settings={theme:settings.theme||'dark',accent:settings.accent||'#b8c4d8',displayName:'Usuário EROM',username:'usuario',avatar:'',banner:''};
  [KEY,SETTINGS,'erom_box_items','erom_box_settings'].forEach(k=>localStorage.removeItem(k));
  Object.keys(localStorage).filter(k=>k.startsWith(META)).forEach(k=>localStorage.removeItem(k))}

/* ---------- perfil e preferências ---------- */
async function pullProfile(){
  const meta=loadMeta();
  let {data:p,error}=await client.from('profiles').select('*').eq('user_id',uid).maybeSingle();
  if(error)throw error;
  if(!p){const {data:{session}}=await client.auth.getSession();const un=(session&&session.user&&session.user.user_metadata&&session.user.user_metadata.username)||'usuario';
    const r=await client.rpc('save_profile',{p_display_name:String(un).slice(0,40),p_username:String(un)});if(r.error)throw r.error;p=r.data}
  settings.displayName=p.display_name;settings.username=p.username;settings.avatar=p.avatar||'';settings.banner=p.banner||'';
  settings.changeCount=Number(p.change_count)||0;settings.lastChangeAt=p.last_change_at||null;
  if(!meta.dirty&&p.settings&&typeof p.settings==='object'){for(const k of ['theme','accent','logoStyle'])if(typeof p.settings[k]==='string')settings[k]=p.settings[k]}
  meta.prof={a:hash(p.avatar||''),b:hash(p.banner||''),s:hash(stable(p.settings||{}))};
  saveMeta(meta);
  localStorage.setItem(SETTINGS,JSON.stringify(settings));
  applySettings();renderProfile()}
async function pushProfile(){
  const meta=loadMeta();const prefs={theme:settings.theme||'dark',accent:settings.accent||'#b8c4d8',logoStyle:settings.logoStyle==='gold'?'gold':'silver'};
  const upd={};
  const hs=hash(stable(prefs)),ha=hash(settings.avatar||''),hb=hash(settings.banner||'');
  if(meta.prof.s!==hs)upd.settings=prefs;
  if(meta.prof.a!==ha)upd.avatar=settings.avatar||null;
  if(meta.prof.b!==hb)upd.banner=settings.banner||null;
  if(!Object.keys(upd).length){if(meta.dirty){meta.dirty=false;saveMeta(meta)}return}
  const {error}=await client.from('profiles').update(upd).eq('user_id',uid);
  if(error)throw error;
  meta.prof={s:hs,a:ha,b:hb};meta.dirty=false;saveMeta(meta)}

/* ---------- biblioteca ---------- */
async function pull(){
  const {data:rows,error}=await client.from('library_items').select('id,kind,collection,title,data,poster,updated_ms,deleted').order('updated_ms',{ascending:true}).range(0,999);
  if(error)throw error;
  const meta=loadMeta(),byId=new Map(items.map(x=>[x.id,x]));let changed=false;
  for(const r of rows){
    const l=byId.get(r.id),lt=l?(Number(l.updated)||Number(l.created)||0):0,rt=Number(r.updated_ms)||0;
    if(r.deleted){
      if(l&&lt>rt)continue;                       /* editado depois da exclusão: mantém e reenvia */
      if(l){byId.delete(r.id);changed=true}
      meta.map[r.id]={h:'',k:r.kind,d:1};
    }else if(!l||rt>lt){
      const it=fromRow(r);byId.set(r.id,it);meta.map[r.id]={h:hashItem(it),k:it.kind};changed=true;
    }else if(rt===lt){meta.map[r.id]={h:hashItem(l),k:l.kind}}
  }
  if(changed){items=[...byId.values()].sort((a,b)=>(Number(b.created)||0)-(Number(a.created)||0));localStorage.setItem(KEY,JSON.stringify(items))}
  saveMeta(meta);if(changed)render();
  const cutoff=Date.now()-90*86400000;                 /* limpa lápides antigas */
  client.from('library_items').delete().eq('deleted',true).lt('updated_ms',cutoff).then(()=>{},()=>{})}
async function pushItems(){
  const meta=loadMeta(),now=Date.now(),rows=[],ids=new Set(items.map(x=>x.id));let touched=false;
  for(const it of items){const h=hashItem(it),m=meta.map[it.id];
    if(!m||m.h!==h||m.d){if(m&&!m.d&&m.h!==h){it.updated=now;touched=true}else if(!it.updated){it.updated=it.created||now;touched=true}
      rows.push({row:toRow(it),h,k:it.kind})}}
  for(const [id,m] of Object.entries(meta.map)){if(!m.d&&!ids.has(id))rows.push({row:{user_id:uid,id,kind:m.k||'Filme',collection:'library',title:'',data:{},poster:null,updated_ms:now,deleted:true},h:'',k:m.k,del:1})}
  if(touched)localStorage.setItem(KEY,JSON.stringify(items));
  for(let i=0;i<rows.length;i+=12){
    const chunk=rows.slice(i,i+12);
    const {error}=await client.from('library_items').upsert(chunk.map(c=>c.row),{onConflict:'user_id,id'});
    if(error)throw error;
    for(const c of chunk)meta.map[c.row.id]=c.del?{h:'',k:c.k,d:1}:{h:c.h,k:c.k};
    saveMeta(meta)}}
async function push(){
  if(!cloudReady||!uid)return;
  if(pushing){pushAgain=true;return}
  pushing=true;
  try{await pushProfile();await pushItems();status('Conta conectada · sincronizado às '+hhmm())}
  catch(e){console.error('EROM BOX sync',e);status(isNetwork(e)?'Sem conexão: suas alterações serão enviadas quando a internet voltar.':'Não foi possível sincronizar: '+friendly(e))}
  finally{pushing=false;if(pushAgain){pushAgain=false;schedule()}}}
function schedule(){if(!cloudReady)return;clearTimeout(timer);timer=setTimeout(push,700)}
async function resync(){
  if(!cloudReady||!uid)return;
  try{status('Sincronizando…');await pullProfile();await pull();lastPull=Date.now();await push()}
  catch(e){console.error('EROM BOX sync',e);status(isNetwork(e)?'Sem conexão: usando os dados salvos neste aparelho.':'Não foi possível sincronizar: '+friendly(e))}}
window.EromHooks.items=schedule;
window.EromHooks.settings=()=>{if(!cloudReady)return;const m=loadMeta();m.dirty=true;saveMeta(m);schedule()};

/* ---------- sessão ---------- */
async function enterSession(){
  if(recovery){showGate();setMode('recovery');return}
  if(entering)return;entering=true;
  try{
    const {data:{session}}=await client.auth.getSession();
    const user=session&&session.user;
    if(!user){showGate();setMode('login');return}
    if(localStorage.getItem(LAST_UID)&&localStorage.getItem(LAST_UID)!==user.id)wipeLocal();   /* nunca mistura dados de contas diferentes */
    localStorage.setItem(LAST_UID,user.id);uid=user.id;cloudReady=true;
    load();try{settings={...settings,...JSON.parse(localStorage.getItem(SETTINGS)||'{}')}}catch{}
    applySettings();renderProfile();render();hideGate();
    await resync();
  }catch(e){console.error(e);showGate();message('Não foi possível entrar: '+friendly(e),true)}
  finally{entering=false}}
async function signOutLocal(){cloudReady=false;uid=null;wipeLocal();applySettings();renderProfile();render();localStorage.removeItem(LAST_UID)}
window.eromAuthSignOut=async()=>{if(!client)return;try{await client.auth.signOut()}catch(e){console.error(e)}await signOutLocal();showGate();setMode('login');message('Você saiu da conta.')};

async function submit(){
  const email=$id('authEmail').value.trim(),password=$id('authPassword').value,button=$id('authSubmit');
  if(!client){message('A conexão online não foi iniciada. Verifique a configuração do Supabase.',true);return}
  button.disabled=true;message('Aguarde…');
  try{
    if(mode==='recovery'){
      if(!password||password.length<8){message('A senha precisa ter pelo menos 8 caracteres.',true);return}
      const {error}=await client.auth.updateUser({password});if(error)throw error;
      recovery=false;try{history.replaceState(null,'',location.pathname)}catch{}
      message('Senha atualizada! Entrando…');await enterSession();return}
    if(!email){message('Digite seu e-mail.',true);return}
    if(mode==='reset'){
      const {error}=await client.auth.resetPasswordForEmail(email,{redirectTo:SITE_URL||(location.origin+'/')});if(error)throw error;
      message('Se a conta existir, enviaremos um link de recuperação. Confira também o spam.');return}
    if(mode==='signup'){
      const username=$id('authUsername').value.trim().replace(/^@+/,''),n=Array.from(username).length;
      if(n<3||n>24){message('O nome de usuário (@) deve ter de 3 a 24 caracteres.',true);return}
      if(!password||password.length<8){message('A senha precisa ter pelo menos 8 caracteres.',true);return}
      const {data,error}=await client.auth.signUp({email,password,options:{data:{username},emailRedirectTo:SITE_URL||(location.origin+'/')}});
      if(error)throw error;
      if(!data.session){const r=await client.auth.signInWithPassword({email,password});if(r.error)throw r.error}
      message('Conta criada! Entrando…');await enterSession();
    }else{
      const {error}=await client.auth.signInWithPassword({email,password});if(error)throw error;
      await enterSession()}
  }catch(e){message(friendly(e),true)}
  finally{button.disabled=false}}
$id('authSubmit').addEventListener('click',submit);
$id('authPassword').addEventListener('keydown',e=>{if(e.key==='Enter')submit()});
$id('authEmail').addEventListener('keydown',e=>{if(e.key==='Enter')submit()});
$id('authShowLogin').onclick=()=>setMode('login');$id('authShowSignup').onclick=()=>setMode('signup');$id('authForgot').onclick=()=>setMode('reset');

/* ---------- exclusão segura da conta (Edge Function delete-account) ---------- */
function dialog(html){return new Promise(resolve=>{
  const o=document.createElement('div');o.style.cssText='position:fixed;inset:0;z-index:99999;background:rgba(0,0,0,.68);display:flex;align-items:center;justify-content:center;padding:22px';
  const d=document.createElement('div');d.style.cssText='width:min(100%,420px);background:var(--panel,#11151d);color:var(--text,#f5f7fb);border:1px solid var(--line,#272e3b);border-radius:24px;padding:26px;box-shadow:0 18px 70px #0008;box-sizing:border-box';
  d.innerHTML=html;o.appendChild(d);document.body.appendChild(o);
  d.querySelector('[data-no]').onclick=()=>{o.remove();resolve(false)};d.querySelector('[data-yes]').onclick=()=>{o.remove();resolve(true)};
  o.addEventListener('click',e=>{if(e.target===o){o.remove();resolve(false)}})})}
$id('deleteAccountBtn')?.addEventListener('click',async()=>{
  if(!client||!cloudReady){alert('Entre na sua conta (com internet) para excluí-la.');return}
  const ok=await dialog('<h2 style="margin:0 0 12px">Excluir sua conta?</h2><p style="margin:0 0 24px;line-height:1.5">Sua conta, perfil e toda a biblioteca serão apagados para sempre. Essa ação não pode ser desfeita.</p><div style="display:flex;gap:12px;justify-content:flex-end"><button type="button" class="btn" data-no>Cancelar</button><button type="button" class="btn danger" data-yes>Excluir</button></div>');
  if(!ok)return;
  const btn=$id('deleteAccountBtn');btn.disabled=true;btn.textContent='Excluindo…';
  try{
    const {error}=await client.functions.invoke('delete-account');if(error)throw error;
    try{await client.auth.signOut({scope:'local'})}catch{}
    await signOutLocal();
    const t=document.createElement('div');t.style.cssText='position:fixed;inset:0;z-index:100000;background:rgba(0,0,0,.72);display:flex;align-items:center;justify-content:center;padding:24px';
    t.innerHTML='<div style="background:var(--panel,#11151d);color:var(--text,#f5f7fb);border:1px solid var(--line,#272e3b);border-radius:24px;padding:30px;text-align:center;max-width:420px;width:100%;box-sizing:border-box"><h2 style="margin-top:0">Obrigado por fazer parte da Erom Box 💜</h2><p>Sua conta foi excluída.</p><button type="button" class="btn primary" id="closeThanks">OK</button></div>';
    document.body.appendChild(t);t.querySelector('#closeThanks').onclick=()=>location.reload();
  }catch(e){console.error(e);alert('Não foi possível excluir a conta agora. Verifique a internet e tente de novo.');btn.disabled=false;btn.textContent='Excluir minha conta permanentemente'}});

/* ---------- API para o resto do app ---------- */
window.EromCloud={
  ready:()=>cloudReady,
  online:()=>cloudReady&&navigator.onLine,
  async saveProfile(name,user){const {data,error}=await client.rpc('save_profile',{p_display_name:name,p_username:user});if(error)throw new Error(error.message);return data}
};

/* ---------- inicialização ---------- */
(async function init(){
  try{
    if(!window.supabase||!SUPABASE_URL||!SUPABASE_KEY){message('Configuração do Supabase ausente.',true);showGate();return}
    client=window.supabase.createClient(SUPABASE_URL,SUPABASE_KEY,{auth:{persistSession:true,autoRefreshToken:true,detectSessionInUrl:true}});
    client.auth.onAuthStateChange((event,session)=>{
      if(event==='SIGNED_OUT'){if(cloudReady){signOutLocal();showGate();setMode('login')}}
      else if(event==='PASSWORD_RECOVERY'){recovery=true;showGate();setMode('recovery')}
      else if(event==='SIGNED_IN'&&session&&!(cloudReady&&uid===session.user.id)){setTimeout(enterSession,0)}});
    const {data:{session}}=await client.auth.getSession();
    if(session)await enterSession();else{showGate();setMode('login')}
  }catch(e){console.error(e);showGate();message('Erro ao iniciar a conexão. '+friendly(e),true)}
})();
document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='visible'&&cloudReady&&Date.now()-lastPull>30000)resync()});
window.addEventListener('online',()=>{if(cloudReady)resync()});
})();
