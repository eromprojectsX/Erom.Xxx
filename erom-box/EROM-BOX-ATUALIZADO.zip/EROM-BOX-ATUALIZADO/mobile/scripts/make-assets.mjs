// Gera os ícones PNG do app a partir de ../branding/logo.svg (roda sozinho no build do EAS).
import { mkdirSync, existsSync } from 'node:fs';
const out = new URL('../assets/', import.meta.url).pathname;
try {
  const sharp = (await import('sharp')).default;
  const src = new URL('../../branding/logo.svg', import.meta.url).pathname;
  if (!existsSync(src)) throw new Error('branding/logo.svg não encontrado');
  mkdirSync(out, { recursive: true });
  const black = { r: 0, g: 0, b: 0, alpha: 1 };
  await sharp(src, { density: 300 }).resize(1024, 1024).png().toFile(out + 'icon.png');
  await sharp(src, { density: 300 }).resize(1024, 1024).png().toFile(out + 'splash.png');
  await sharp(src, { density: 300 }).resize(680, 680).extend({ top: 172, bottom: 172, left: 172, right: 172, background: black }).png().toFile(out + 'adaptive-icon.png');
  console.log('make-assets: ok');
} catch (e) {
  if (existsSync(out + 'icon.png')) console.warn('make-assets: ignorado (' + e.message + '); usando assets existentes.');
  else { console.error('make-assets falhou: ' + e.message); process.exit(1); }
}
