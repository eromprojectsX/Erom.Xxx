import React, { useCallback, useEffect, useRef, useState } from 'react';
import { ActivityIndicator, BackHandler, Linking, Platform, Pressable, StatusBar, StyleSheet, Text, View } from 'react-native';
import { WebView } from 'react-native-webview';
import Constants from 'expo-constants';
import * as FileSystem from 'expo-file-system/legacy';
import * as Sharing from 'expo-sharing';

const SITE = (Constants.expoConfig?.extra?.siteUrl || 'https://erombox.netlify.app/').replace(/\/*$/, '/');
const HOST = new URL(SITE).host;
const ALLOWED = [HOST, 'supabase.co'];

export default function App() {
  const web = useRef(null);
  const [canGoBack, setCanGoBack] = useState(false);
  const [failed, setFailed] = useState(false);
  const [loading, setLoading] = useState(true);

  // Botão voltar do Android navega dentro do app e só depois fecha.
  useEffect(() => {
    if (Platform.OS !== 'android') return undefined;
    const sub = BackHandler.addEventListener('hardwareBackPress', () => {
      if (canGoBack && web.current) { web.current.goBack(); return true; }
      return false;
    });
    return () => sub.remove();
  }, [canGoBack]);

  // Ponte: o site pede para salvar o backup (.json) e o app abre a folha de compartilhamento.
  const onMessage = useCallback(async (event) => {
    try {
      const msg = JSON.parse(event.nativeEvent.data);
      if (msg.type === 'export' && typeof msg.content === 'string') {
        const safe = String(msg.filename || 'erom-box-backup.json').replace(/[^\w.-]/g, '_');
        const uri = FileSystem.cacheDirectory + safe;
        await FileSystem.writeAsStringAsync(uri, msg.content, { encoding: FileSystem.EncodingType.UTF8 });
        if (await Sharing.isAvailableAsync()) await Sharing.shareAsync(uri, { mimeType: 'application/json', dialogTitle: 'Salvar backup do EROM BOX' });
      }
    } catch (e) { /* mensagem inválida: ignora */ }
  }, []);

  // Só abre dentro do app o próprio site e o Supabase; links externos vão para o navegador.
  const shouldLoad = useCallback((req) => {
    try {
      const u = new URL(req.url);
      if (u.protocol === 'about:' || u.protocol === 'blob:' || u.protocol === 'data:') return true;
      if (ALLOWED.some((h) => u.host === h || u.host.endsWith('.' + h))) return true;
      Linking.openURL(req.url).catch(() => {});
      return false;
    } catch { return false; }
  }, []);

  const retry = () => { setFailed(false); setLoading(true); web.current?.reload(); };

  return (
    <View style={styles.root}>
      <StatusBar barStyle="light-content" backgroundColor="#000000" />
      <WebView
        ref={web}
        source={{ uri: SITE }}
        style={styles.web}
        originWhitelist={['https://*', 'about:*']}
        javaScriptEnabled
        domStorageEnabled
        cacheEnabled
        sharedCookiesEnabled
        setSupportMultipleWindows={false}
        allowsBackForwardNavigationGestures
        onNavigationStateChange={(s) => setCanGoBack(s.canGoBack)}
        onShouldStartLoadWithRequest={shouldLoad}
        onMessage={onMessage}
        onLoadEnd={() => setLoading(false)}
        onError={() => { setFailed(true); setLoading(false); }}
        onHttpError={(e) => { if (e.nativeEvent.statusCode >= 500) { setFailed(true); setLoading(false); } }}
        userAgent={undefined}
      />
      {loading && !failed && (<View style={styles.overlay}><ActivityIndicator color="#ffffff" size="large" /></View>)}
      {failed && (
        <View style={styles.overlay}>
          <Text style={styles.title}>Sem conexão</Text>
          <Text style={styles.text}>Não foi possível abrir o EROM BOX. Verifique a internet e tente de novo.</Text>
          <Pressable style={styles.btn} onPress={retry}><Text style={styles.btnText}>Tentar novamente</Text></Pressable>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#000000', paddingTop: Platform.OS === 'android' ? StatusBar.currentHeight || 0 : 0 },
  web: { flex: 1, backgroundColor: '#000000' },
  overlay: { ...StyleSheet.absoluteFillObject, backgroundColor: '#000000', alignItems: 'center', justifyContent: 'center', padding: 28 },
  title: { color: '#ffffff', fontSize: 22, fontWeight: '800', marginBottom: 8 },
  text: { color: '#9ba5b5', fontSize: 15, textAlign: 'center', marginBottom: 20 },
  btn: { backgroundColor: '#b8c4d8', paddingHorizontal: 22, paddingVertical: 12, borderRadius: 12 },
  btnText: { color: '#080a0f', fontWeight: '800' },
});
