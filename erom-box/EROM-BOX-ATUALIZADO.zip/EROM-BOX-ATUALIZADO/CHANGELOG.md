# Changelog

## 2.0.0 — 2026-10-13
- Cadastro sem confirmação por e-mail: só usuário, e-mail e senha; a conta é criada e o app entra direto.
- Login real (Supabase): cadastro, entrar, sair, recuperar senha com tela "Definir nova senha", sessão mantida no F5, exclusão segura da conta.
- Dados privados por usuário (RLS) e sincronização por item entre aparelhos, com exclusões e modo offline.
- Regras de nome de exibição/@ aplicadas no servidor (2 alterações, pausa de 30 dias).
- Logo vetorial animada: abertura de 3,8 s, fita de filme em movimento, versão dourada nas configurações.
- PWA: manifest, ícones, service worker (offline). Projeto Android (Expo) em `mobile/`.
- Sentry para erros; cabeçalhos de segurança no Netlify; variáveis de ambiente.
- Código separado em arquivos (`public/assets/*`).
- Corrigido: o seletor de categoria do formulário não alternava os campos; "Próximo episódio" não atualizava o progresso total.
- Corrigido: backup importado agora é validado; imagens são reduzidas antes de salvar.
- Removido: senha de teste do "modo desenvolvedor local" no código público.
