// Servidor SIMULADO do Supabase para testes locais (não usa a internet). Aplica as mesmas regras do banco real.
import http from 'node:http';
const db = { users: {}, profiles: {}, items: {}, clock: 0 };
const now = () => Date.now() + db.clock;
const uid = () => 'u-' + Math.random().toString(36).slice(2, 10);
const send = (res, code, body) => { res.writeHead(code, { 'content-type': 'application/json', 'access-control-allow-origin': '*', 'access-control-allow-headers': '*' }); res.end(JSON.stringify(body)); };
const chars = (s) => Array.from(s).length;
function saveProfile(u, name, user) {
  name = (name || '').trim(); user = (user || '').trim().replace(/^@+/, '');
  if (!name) return { error: 'Digite um nome de exibição.' };
  if (chars(user) < 3 || chars(user) > 24) return { error: 'O @ do usuário deve ter de 3 a 24 caracteres.' };
  const p = db.profiles[u];
  if (name === p.display_name && user === p.username) return { data: p };
  let c = p.change_count;
  if (c >= 2) {
    const until = new Date(p.last_change_at).getTime() + 30 * 864e5;
    if (now() < until) return { error: `Você já usou as 2 alterações. Poderá alterar o nome de exibição e o @ novamente em ${Math.ceil((until - now()) / 864e5)} dia(s).` };
    c = 0;
  }
  Object.assign(p, { display_name: name, username: user, change_count: c + 1, last_change_at: new Date(now()).toISOString() });
  return { data: p };
}
http.createServer((req, res) => {
  if (req.method === 'OPTIONS') return send(res, 204, {});
  let b = ''; req.on('data', d => b += d); req.on('end', () => {
    const q = b ? JSON.parse(b) : {}; const u = q.token;
    try {
      switch (q.op) {
        case 'reset': Object.assign(db, { users: {}, profiles: {}, items: {}, clock: 0 }); return send(res, 200, {});
        case 'clock': db.clock += q.ms; return send(res, 200, {});
        case 'dump': return send(res, 200, { users: Object.keys(db.users).length, profiles: db.profiles, items: db.items });
        case 'signUp': {
          if (db.users[q.email]) return send(res, 200, { error: 'User already registered' });
          const id = uid(); db.users[q.email] = { id, password: q.password };
          const name = (q.username || 'usuario'); db.profiles[id] = { user_id: id, username: name, display_name: name, avatar: null, banner: null, settings: {}, change_count: 0, last_change_at: null };
          db.items[id] = {}; return send(res, 200, { data: { id, email: q.email } });
        }
        case 'signIn': {
          const x = db.users[q.email]; if (!x || x.password !== q.password) return send(res, 200, { error: 'Invalid login credentials' });
          return send(res, 200, { data: { id: x.id, email: q.email } });
        }
        case 'profile': return send(res, 200, { data: db.profiles[u] || null });
        case 'profileUpdate': { if (!db.profiles[u]) return send(res, 200, { error: 'no profile' }); for (const k of Object.keys(q.upd)) if (!['avatar', 'banner', 'settings'].includes(k)) return send(res, 200, { error: 'permission denied for table profiles' }); Object.assign(db.profiles[u], q.upd); return send(res, 200, {}); }
        case 'saveProfile': { if (!db.profiles[u]) return send(res, 200, { error: 'Faça login' }); return send(res, 200, saveProfile(u, q.name, q.user)); }
        case 'itemsSelect': return send(res, 200, { data: Object.values(db.items[u] || {}) });
        case 'itemsUpsert': {
          const m = (db.items[u] = db.items[u] || {});
          for (const r of q.rows) {
            if (r.user_id !== u) return send(res, 200, { error: 'new row violates row-level security policy for table "library_items"' });
            if (!['Filme', 'Série', 'Desenho'].includes(r.kind)) return send(res, 200, { error: 'check constraint kind' });
            if (r.poster && r.poster.length > 150000) return send(res, 200, { error: 'library_poster_len' });
            m[r.id] = r;
          }
          return send(res, 200, {});
        }
        case 'itemsPurge': { const m = db.items[u] || {}; for (const [k, r] of Object.entries(m)) if (r.deleted && r.updated_ms < q.before) delete m[k]; return send(res, 200, {}); }
        case 'deleteAccount': { for (const [e, x] of Object.entries(db.users)) if (x.id === u) delete db.users[e]; delete db.profiles[u]; delete db.items[u]; return send(res, 200, { data: { success: true } }); }
        case 'updatePassword': { for (const x of Object.values(db.users)) if (x.id === u) x.password = q.password; return send(res, 200, {}); }
      }
      send(res, 400, { error: 'op?' });
    } catch (e) { send(res, 500, { error: String(e) }); }
  });
}).listen(8766, () => console.log('mock supabase em :8766'));
