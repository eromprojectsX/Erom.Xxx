"""Teste ponta a ponta do EROM BOX contra um Supabase SIMULADO (tests/mock-server.mjs).
Uso: python3 tests/e2e.py   (sobe os servidores sozinho)"""
import asyncio, json, subprocess, time, urllib.request, sys, os
from playwright.async_api import async_playwright
ROOT=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
APP='http://localhost:8765/index.html'
results=[]
def check(name,cond,extra=''):
    results.append((name,bool(cond))); print(('PASS ' if cond else 'FAIL ')+name+(' | '+str(extra) if extra and not cond else ''))
def api(body):
    r=urllib.request.Request('http://localhost:8766/',data=json.dumps(body).encode(),method='POST')
    return json.loads(urllib.request.urlopen(r).read())
MOCK=open(os.path.join(ROOT,'tests/mock-supabase.js')).read()

async def newctx(b,vp=(390,844)):
    ctx=await b.new_context(viewport={'width':vp[0],'height':vp[1]},service_workers='block')
    page=await ctx.new_page(); errs=[]
    page.on('pageerror',lambda e:errs.append(str(e)))
    page.on('dialog',lambda d:asyncio.ensure_future(d.accept()))
    await page.route('**/cdn.jsdelivr.net/**',lambda r:r.fulfill(body=MOCK,content_type='application/javascript'))
    await page.route('**/js.sentry-cdn.com/**',lambda r:r.fulfill(body='',content_type='application/javascript'))
    return ctx,page,errs
async def open_app(page):
    await page.goto(APP)
    await page.wait_for_function("document.getElementById('splash').classList.contains('done')",timeout=8000)
async def settle(page,ms=1500): await page.wait_for_timeout(ms)
async def toast(page): return await page.inner_text('#toast')
async def add_series(page,title,eps=(10,8),season=1,episode=3,kind='Série'):
    await page.click('#addBtn'); await page.fill('#title',title); await page.select_option('#kind',kind)
    if kind=='Filme':
        await page.fill('#duration','02h00'); await page.fill('#watchedTime','00h30')
    else:
        await page.fill('#totalSeasons',str(len(eps)))
        await page.dispatch_event('#totalSeasons','input')
        for i,n in enumerate(eps,1): await page.fill(f'#seasonCount{i}',str(n))
        await page.fill('#season',str(season)); await page.fill('#episode',str(episode))
        await page.dispatch_event('#episode','input')
    await page.click('#contentForm button[type=submit]')
    await settle(page,1400)
async def login(page,email,pw):
    await page.fill('#authEmail',email); await page.fill('#authPassword',pw); await page.click('#authSubmit')
    await page.wait_for_function("document.body.classList.contains('authenticated')",timeout=8000)

async def main():
    api({'op':'reset'})
    async with async_playwright() as p:
        b=await p.chromium.launch()
        # 1) cadastro (com @ contendo espaço/emoji) ------------------------------------------------
        ctxA,A,errA=await newctx(b); await open_app(A)
        check('sem sessão: mostra tela de login',await A.evaluate("getComputedStyle(document.getElementById('authGate')).display")=='flex')
        await A.click('#authShowSignup'); await A.fill('#authUsername','@Maria ✨'); 
        await A.fill('#authEmail','maria@teste.com'); await A.fill('#authPassword','curta'); await A.click('#authSubmit'); await settle(A,300)
        check('senha curta é recusada',('8 caracteres' in await A.inner_text('#authMessage')))
        await A.fill('#authUsername','ab'); await A.fill('#authPassword','senhaBoa123'); await A.click('#authSubmit'); await settle(A,300)
        check('@ curto é recusado no cadastro',('3 a 24' in await A.inner_text('#authMessage')))
        await A.fill('#authUsername','@Maria ✨'); await A.click('#authSubmit')
        await A.wait_for_function("document.body.classList.contains('authenticated')",timeout=8000); await settle(A,800)
        check('cadastro entra no app e mostra o @ do servidor',(await A.inner_text('#profileHandle'))=='@Maria ✨',await A.inner_text('#profileHandle'))
        # 1b) cadastro quando o servidor NÃO devolve sessão: o app entra direto mesmo assim
        ctxN,N,errN=await newctx(b); await N.add_init_script("localStorage.setItem('mock-nosession','1')"); await open_app(N)
        await N.click('#authShowSignup'); await N.fill('#authUsername','sem_confirmar'); await N.fill('#authEmail','semconfirmar@hotmail.com'); await N.fill('#authPassword','senhaBoa123'); await N.click('#authSubmit')
        await N.wait_for_function("document.body.classList.contains('authenticated')",timeout=8000)
        check('cadastro só com usuário, e-mail e senha entra direto (sem confirmar e-mail)',True)
        await ctxN.close()
        # 2) criar série pela interface -> sincroniza ------------------------------------------------
        await add_series(A,'Avatar: A Lenda de Aang',eps=(10,8),season=1,episode=3,kind='Desenho')
        d=api({'op':'dump'}); uidA=list(d['profiles'].keys())[0]; rows=list(d['items'][uidA].values())
        check('item chegou ao servidor com a categoria correta',len(rows)==1 and rows[0]['kind']=='Desenho',rows)
        check('progresso automático: 3 de 18 episódios',rows and rows[0]['data'].get('watchedEpisodes')=='3' and rows[0]['data'].get('totalEpisodes')=='18',rows[0]['data'] if rows else '')
        itemId=rows[0]['id']
        # 3) F5 mantém a sessão -----------------------------------------------------------------------
        await open_app(A); await settle(A,800)
        check('F5 mantém logado',await A.evaluate("document.body.classList.contains('authenticated')"))
        check('F5 mantém a biblioteca',(await A.inner_text('#homeStats')).count('1')>=1 and 'Avatar' in await A.inner_text('#continueGrid'))
        # 4) segundo aparelho vê os dados e edita ------------------------------------------------------
        ctxB,B,errB=await newctx(b); await open_app(B)
        await login(B,'maria@teste.com','senhaBoa123'); await settle(B,1200)
        check('aparelho B recebe a biblioteca do aparelho A','Avatar' in await B.inner_text('#continueGrid'))
        await B.click('.nav button[data-view=seasons]'); await settle(B,300)
        await B.click('[data-next]'); await settle(B,1500)
        r=api({'op':'dump'})['items'][uidA][itemId]
        check('"Próximo episódio" atualiza progresso (4 de 18) e sincroniza',r['data'].get('episode')=='4' or r['data'].get('episode')==4 and r['data'].get('watchedEpisodes')=='4',r['data'])
        await A.evaluate("window.dispatchEvent(new Event('online'))"); await settle(A,1500)
        cached=json.loads(await A.evaluate("localStorage.getItem('erombox-library-v2-clean')"))
        check('aparelho A recebe a edição do B',cached and str(cached[0].get('watchedEpisodes'))=='4',cached[0] if cached else '')
        # 5) exclusão sincroniza (lápide) ---------------------------------------------------------------
        await A.click('.card[data-detail]'); await A.click('#detailDelete'); await settle(A,1600)
        r=api({'op':'dump'})['items'][uidA][itemId]
        check('exclusão vira lápide no servidor',r['deleted'] is True)
        await B.evaluate("window.dispatchEvent(new Event('online'))"); await settle(B,1500)
        check('exclusão chega ao aparelho B','Avatar' not in await B.inner_text('#continueGrid'))
        # 6) regras do perfil (2 alterações / 30 dias) ----------------------------------------------------
        await A.click('.nav button[data-view=profile]'); await settle(A,300)
        async def save_profile(name,user):
            await A.fill('#displayNameInput',name); await A.fill('#usernameInput',user); await A.click('#saveProfileBtn'); await settle(A,700); return await toast(A)
        t=await save_profile('Maria Silva','@Maria ✨'); check('1ª alteração aceita (1 de 2)','1 de 2' in t,t)
        t=await save_profile('Maria Silva','@maria_s 🎬'); check('2ª alteração aceita e avisa pausa','2 alterações' in t,t)
        t=await save_profile('Outro Nome','@maria_s 🎬'); check('3ª alteração bloqueada pelo servidor','já usou as 2 alterações' in t,t)
        check('nome não mudou após bloqueio',(await A.inner_text('#profileDisplayName'))=='Maria Silva')
        t=await save_profile('Maria Silva','@ab'); check('@ curto recusado no perfil','3 a 24' in t,t)
        api({'op':'clock','ms':31*86400000})
        t=await save_profile('Maria 2','@maria_s 🎬'); check('após 30 dias libera nova alteração','Perfil salvo' in t and 'já usou' not in t,t)
        # 7) logo dourada persiste na conta ---------------------------------------------------------------
        await A.click('.logo-opt[data-style=gold]'); await settle(A,1500)
        check('logo dourada salva no perfil da nuvem',api({'op':'dump'})['profiles'][uidA]['settings'].get('logoStyle')=='gold')
        # 8) logout limpa dados locais; outro usuário não vê nada do anterior -----------------------------
        await add_series(A,'Série da Maria',eps=(5,),season=1,episode=1,kind='Série'); await settle(A,800)
        await A.click('#loginBtn'); await settle(A,600)
        check('logout limpa a biblioteca local',await A.evaluate("localStorage.getItem('erombox-library-v2-clean')===null"))
        await A.click('#authShowSignup'); await A.fill('#authUsername','joao_dev'); await A.fill('#authEmail','joao@teste.com'); await A.fill('#authPassword','outraSenha123'); await A.click('#authSubmit')
        await A.wait_for_function("document.body.classList.contains('authenticated')",timeout=8000); await settle(A,1500)
        check('outro usuário no mesmo aparelho não vê dados da Maria','Série da Maria' not in await A.inner_text('#recentGrid'))
        d=api({'op':'dump'}); uidJ=[k for k,v in d['profiles'].items() if v['username']=='joao_dev'][0]
        check('nada da Maria foi enviado para a conta do João',len(d['items'].get(uidJ,{}))==0)
        # 9) offline: adiciona e sincroniza quando voltar ---------------------------------------------------
        await ctxA.set_offline(True); await add_series(A,'Filme Offline',eps=(1,),kind='Filme'); await settle(A,800)
        check('offline: item aparece localmente','Filme Offline' in await A.inner_text('#recentGrid'))
        check('offline: ainda não está no servidor',len(api({'op':'dump'})['items'][uidJ])==0)
        await ctxA.set_offline(False); await A.evaluate("window.dispatchEvent(new Event('online'))"); await settle(A,2000)
        check('ao voltar a internet o item é enviado',any(r['title']=='Filme Offline' for r in api({'op':'dump'})['items'][uidJ].values()))
        # 10) recuperação de senha ----------------------------------------------------------------------------
        ctxC,C,errC=await newctx(b)
        await C.goto(APP); await C.wait_for_function("document.getElementById('splash').classList.contains('done')",timeout=8000)
        await login(C,'joao@teste.com','outraSenha123'); await settle(C,500)
        await C.goto('about:blank'); await C.goto(APP+'#access_token=x&refresh_token=y&type=recovery'); await C.wait_for_function("document.getElementById('splash').classList.contains('done')",timeout=8000); await settle(C,800)
        check('link de recuperação abre "Definir nova senha"',(await C.inner_text('#authHeading'))=='Definir nova senha')
        await C.fill('#authPassword','senhaNova456'); await C.click('#authSubmit'); await C.wait_for_function("document.body.classList.contains('authenticated')",timeout=8000)
        check('nova senha salva e entra no app',True)
        # 11) excluir conta ------------------------------------------------------------------------------------
        await A.click('.nav button[data-view=profile]'); await A.locator('#deleteAccountBtn').scroll_into_view_if_needed(); await A.click('#deleteAccountBtn'); await A.click('[data-yes]'); await settle(A,1200)
        d=api({'op':'dump'})
        check('conta e dados apagados no servidor',uidJ not in d['profiles'] and uidJ not in d['items'])
        check('mostra agradecimento após excluir',await A.evaluate("!!document.getElementById('closeThanks')"))
        for n,e in (('A',errA),('B',errB),('C',errC)): check(f'sem erros de JavaScript (aparelho {n})',not e,e)
        await b.close()
    ok=sum(1 for _,c in results if c); print(f'\n{ok}/{len(results)} testes passaram'); sys.exit(0 if ok==len(results) else 1)
asyncio.run(main())
