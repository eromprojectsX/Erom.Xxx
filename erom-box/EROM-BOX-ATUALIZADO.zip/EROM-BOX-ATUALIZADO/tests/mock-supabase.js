/* Cliente SIMULADO do supabase-js (somente testes). Fala com tests/mock-server.mjs. */
(function(){
  const API='http://localhost:8766/';
  const call=async(body)=>{const r=await fetch(API,{method:'POST',body:JSON.stringify(body)});return r.json()};
  const SK='mock-session';
  const getS=()=>{try{return JSON.parse(localStorage.getItem(SK))}catch{return null}};
  let cb=null;
  const emit=(e,s)=>{if(cb)setTimeout(()=>cb(e,s),0)};
  const sess=(u)=>({user:{id:u.id,email:u.email,user_metadata:{}},access_token:u.id});
  function qb(table){
    const st={table,cols:null,eq:{},lt:null,op:'select',rows:null,upd:null};
    const run=async()=>{const s=getS();if(!s)return {data:null,error:{message:'JWT expired'}};
      if(!navigator.onLine)return {data:null,error:{message:'Failed to fetch'}};
      let r;
      try{
      if(table==='library_items'){
        if(st.op==='select'){r=await call({op:'itemsSelect',token:s.user.id});return r.error?{data:null,error:{message:r.error}}:{data:r.data,error:null}}
        if(st.op==='upsert'){r=await call({op:'itemsUpsert',token:s.user.id,rows:st.rows});return {error:r.error?{message:r.error}:null}}
        if(st.op==='delete'){await call({op:'itemsPurge',token:s.user.id,before:st.lt});return {error:null}}
      }
      if(table==='profiles'){
        if(st.op==='select'){r=await call({op:'profile',token:s.user.id});return {data:r.data,error:null}}
        if(st.op==='update'){r=await call({op:'profileUpdate',token:s.user.id,upd:st.upd});return {error:r.error?{message:r.error}:null}}
      }
      }catch(e){return {data:null,error:{message:'Failed to fetch'}}}
      return {data:null,error:{message:'tabela?'}}};
    const o={select(c){st.cols=c;return o},eq(k,v){st.eq[k]=v;return o},lt(k,v){st.lt=v;return o},order(){return o},range(){return o},
      maybeSingle(){return run()},upsert(rows){st.op='upsert';st.rows=rows;return run()},
      update(u){st.op='update';st.upd=u;return o},delete(){st.op='delete';return o},
      then(res,rej){return run().then(res,rej)}};
    return o}
  window.supabase={createClient(){return {
    auth:{
      async getSession(){const s=getS();return {data:{session:s}}},
      onAuthStateChange(f){cb=f;return {data:{subscription:{}}}},
      async signUp({email,password,options}){const r=await call({op:'signUp',email,password,username:options&&options.data&&options.data.username});if(r.error)return {data:null,error:{message:r.error}};if(window.__noSessionOnSignup||localStorage.getItem('mock-nosession')){return {data:{session:null},error:null}}const s=sess(r.data);localStorage.setItem(SK,JSON.stringify(s));emit('SIGNED_IN',s);return {data:{session:s},error:null}},
      async signInWithPassword({email,password}){const r=await call({op:'signIn',email,password});if(r.error)return {data:null,error:{message:r.error}};const s=sess(r.data);localStorage.setItem(SK,JSON.stringify(s));emit('SIGNED_IN',s);return {data:{session:s},error:null}},
      async signOut(){localStorage.removeItem(SK);emit('SIGNED_OUT',null);return {error:null}},
      async updateUser({password}){const s=getS();await call({op:'updatePassword',token:s.user.id,password});return {error:null}},
      async resetPasswordForEmail(){return {error:null}}
    },
    from:qb,
    async rpc(fn,args){const s=getS();if(!navigator.onLine)return {data:null,error:{message:'Failed to fetch'}};const r=await call({op:'saveProfile',token:s.user.id,name:args.p_display_name,user:args.p_username});return r.error?{data:null,error:{message:r.error}}:{data:r.data,error:null}},
    functions:{async invoke(){const s=getS();const r=await call({op:'deleteAccount',token:s.user.id});window.__deleted=true;return {data:r.data,error:null}}}
  }}};
})();
